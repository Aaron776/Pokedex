# Pokedex made with HTML, CSS and JavaScript

You can get the data from the [PokeAPI](https://pokeapi.co/)
